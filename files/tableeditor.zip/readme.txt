﻿
-------------------------
readme.txt
-------------------------


-------------------------
Installing the Tagset
-------------------------

The tagset tagsets.tableEditor can be installed by bringing the program 
tableEditor.tpl into the program editor and running the code, or by 
simply using the %include statement to run it. This will update the 
Sasuser.templat item store by default with this new tagset. 

%include "c:\tableEditor.tpl";

The style Styles.Mystyle which is used in some of the examples is 
compiled along with the tableEditor tagset which will also be saved in 
SASUSER by default. 


-------------------------
Other Information
-------------------------

This tagset initially is an Internet Explorer tagset. This means that the 
options specified should work with I.E., however not guaranteed to work 
with other browsers. Some of the options will work across browsers. 
Future versions I hope to make as much as possible cross browser 
compatible. 

To see examples of these options, extract the contents of this ZIP file 
and open index.html.


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
Options of the Table Editor          Description
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
Style Options          
-----------------------------------------------------------------------------
banner_color_even="color"            creates alternate row colors     
banner_color_odd="color"             creates alternate row colors     
fbanner_color_even="color"           creates alternate even foreground colors
fbanner_color_odd="color"            creates alternate odd foreground colors
col_color_even="color                creates alternate even background column colors
col_color_odd="color"                creates alternate odd background column  colors
gridline_color="color                color internal rules     
gridline="yes|no"                    removes internal gridline     
background_color="color"             controls background color     
background_image="path"              adds background image     
scrollbar_color="color"              modifies scrollbar color     
image_path="path"                    adds logo or image     
image_just="left|right|center"       justifies logo or image     
highlight_color="color"              creates mouse-over color;
                                          generated when there is no background 
                                          color such as styles.mystyle
highlight_cols="column#color"        modifies background color of columns

fontfamily="font"                    modifies fonts overall if none specified     
header_bgcolor="color"               modifies header background color   
header_fgcolor="color"               modifies header foreground color
header_size="size"                   modifies header font size
header_font="font"                   modifies header font name                 

rowheader_bgcolor="color"            modifies header background color   
rowheader_fgcolor="color"            modifies header foreground color
rowheader_size="size"                modifies header font size
rowheader_font="font"                modifies header font   
                                    
data_bgcolor="color"                 modifies data background color
data_fgcolor="color"                 modifies data foreground color
data_size="size"                     modifies data font size
data_font="font"                     modifies data font 

title_bgcolor="color"                modifies title background color
title_style="slant|roman|italic"     modifies data foreground color
title_size="size"                    modifies data font size
title_fgcolor="color"                modifies foreground of title

page_bgcolor="color"                 modifies the page background color
page_fgcolor="color"                 modified the page foreground color

datalabel_bgcolor="color"            modifies the background color of the data label
datalabel_fgcolor="color"            modifies the backoreground color of the data label




  
-----------------------------------------------------------------------------
Dynamic Positioning          
-----------------------------------------------------------------------------
pageheight="value"                  specifies height before scroll bars     
pagewidth="value"                   specifies width before scrollbars;     
                                           percentage value works best 
frozen_headers="yes|no"             freeze column headers; 
                                           single table option.
frozen_rowheaders="yes|no|column#"         freeze row headers;     
                                           single table option used for wide and 
                                           not long tables; do not use for tables
                                           over 700 observations, which would be 
                                           excessively slow
sticky_headers="yes|no"             locks column headers on non Internet Explorer browser
                                    like Chrome, Firefox, Safari, Opera
-----------------------------------------------------------------------------
Page Setup Options          
-----------------------------------------------------------------------------
print_header="string"               generates header text;      
                                           uses ActiveX and is supported 
                                           by I.E. and Windows only
print_footer="string"               generates footer text;
                                           uses ActiveX and is supported 
                                           by I.E. and Windows only
print_zoom="value"                  scale printed output     
orientation="landscape"             modifies orientation;
                                           uses ActiveX and is supported 
                                           by I.E. and Windows only
                                           (To use this option you have to go to the below
                                            file and download the activex control http://www.meadroid.com/scriptx/)
pagebreak="yes|no|number"           deletes, add page breaks;
                                           also specifies the number of tables per page     
left_margin="value"                 changes the left  margin
right_margin="value"                changes the right margin                                                 
top_margin="value"                  changes top margin                                                        
bottom_margin="value"               changes bottom margin;
                                                     
fit2page="yes|no"                   allows output to be scaled to fit the printed page;
                                            you can also use this 
                                            in conjunction with the orientation 
                                            and the margin properties to reduce 
                                            scaling
-----------------------------------------------------------------------------
Table of Contents Options          
-----------------------------------------------------------------------------
open_image_path="path"              adds open image     
closed_image_path="path"            adds closed image     
leaf_image_path="path"              adds leaf image     
toc_background="path"               adds toc background color     
toc_print="yes|no"                  adds print button to the toc;
                                           this prints the individual body file
toc_expand="yes|no"                 expand toc     
-----------------------------------------------------------------------------
Display Options          
-----------------------------------------------------------------------------
drag="yes|no"                       allow items on page to be dragged;     
                                           dragged items are not persisted when 
                                           the page is saved
zoom="percentage"                   scale items on the screen;
                                           applies to all tables
zoom_toogle="yes|no"                adds dynamic selection list to page
table_zoom="100%,200%,300%"         scales list of tables separated by commas

sort="yes|no"                       sort data by clicking on headers     
sort_arrow_color="color"            color of arrows     
sort_image="image path"             image indicating sort ;
                                           sample images located in zip file    
sort_underline="yes"                underline column header;
                                           alerts reader that headers are sortable
header_underline="yes|no"           underline column header;
                                           underlines regardless sort
exclude_summary="yes"               allows filters and sorts to exclude summary;
                                           allows sort and filters to exclude 
                                           grand total in report 
data_type="value1,value2"           overrides the default data type for columns;
                                           valid types are Number,Numberx(formatted numbers),
                                           String, Date, None
describe="yes|no"                   add color to identify data type     
design_mode="yes|no"                allows the HTML to be edited;
                                           edited output is not persisted when 
                                           the page is saved
pagebreak_toggle="yes|no"           interactive control of page breaks     
zoom_toggle="yes|no"                interactive scaling control      
autofilter="yes|no"                 allows data to be filtered     
autofilter_width="value"            allows the width of the filter to be modified;
                                           by default the width is the same as 
                                           the width of the cell
autofilter_endcol="value"           column number to end filter     
autofilter_table="value"            table to filter; 
                                           the default is ALL
filter_cols="1,2,3"                 column to add filter info     
style_switch="yes"                  allows styles to be switched on the fly;
                                           requires that you read existing CSS 
                                           files to add to the selection
hide_cols="yes|no"                  allows removal of columns;
                                           double click on column headers to remove
reorder_cols="yes|no"               provides the ability to dynamically reorder columns
web_tabs="Label1,Label2"            allows tabs on web page which names output 
web_tabs_bgcolor="blue"             specifies background color for tabs
web_tabs_fgcolor="red"              specifies foreground color for web_tabs
panelcols="number"                  number of columns to panel tables and graphs
header_display="yes|no"             allows removal of the column headers
header_vertical="yes|no"            allows the headers to be  displayed vertically
nowrap="yes|no"                     prevents wrapped text in the browser or when exported to Excel
align_cols="left,right"             Allows columns to be aligned based on the position in the list
jq_datatables="yes|no"              Allows interactive features such as filtering, sorting, limiting 
                                           or expanding displayed content using hosted JQuery library
           
                                        
-----------------------------------------------------------------------------
Exporting Data          
-----------------------------------------------------------------------------
excel_sheet_prompt="yes|no"                prompt to name sheet     
excel_save_prompt="yes|no"                 prompt to save file     
excel_save_dialog="yes|no"                 provide dialog to save file     
excel_save_file="path"                     save file by providing path     
excel_autofilter="yes|no|number"           generate autofilters     
excel_frozen_headers="yes|no|number"       freeze headers     
excel_orientation="yes|no"                 page orientation     
sheet_name="name"
sheet_name="first"                        specify a sheet name
                                                  
excel_table_move="1"
excel_table_move="1,2,3"                   table from the page to move to Excel;
                                                  this can a single value or a list of 
                                                  values separated by commas (This was depracated with release v2.30)
file_format="ext"                          supply format of excel file ;     
                                                  default is xls which is native Excel 
                                                  format; other formats are 
                                                  txt, csv, doc, xml, slk, html

auto_format="format name"                  specifies Excel's format 
auto_format_select="yes|no"                allows Excel's format to be chosen dynamically    
excel_macro="'file!macro'"                 specify VBA macro to execute     
excel_scale="number"                       scale output printed output     
excel_zoom="number"                        specifies zoom for the worksheet     
excel_default_width="number"               default width of each cell;
                                                  helps prevent wrapping 
excel_default_height="number"              default height of each cell;
                                                  helps prevent wrapping
query_range="value"                       location to begin writing data; 
                                                  query_ange="A11"
query_target="file-path"                  file which is updated   
query_file="file-path"                    file which will provide the updating
                                                  to 
       
update_target="xls-file"                   file to update;
                                              can b used with the sheet_name= and the
                                              excel_table_move option to update workbooks     
update_range="value"                       location to write the file     
                                                    update_range="11,1"
update_sheet="sheet name"                  specifies the sheet to update     
open_excel="yes|no"                        determines if Excel is visible or not
quit="yes|no"                              quits Excel and frees memory
pivotrow="name(s)|number(s)"               column names or numbers for pivot rows;     
                                                     to select more than one, separate 
                                                     list items with commas
pivotcol="names(s)|number(s)"              column names or number for pivot columns;     
                                                     to select more than one, separate 
                                                     list items with commas
pivotpage=’names(s)|number(s)              column names or numbers for pivot page;     
                                                     to select more than one, separate 
                                                     list items with commas
pivotdata="name(s)|number(s)               column names or numbers for data;     
                                                     to select more than one, separate 
                                                     list items with commas
Pivotrow_fmt="@"                           formats the row fields in the pivot table
Pivotcol_fmt="@"                           formats the column fields in the pivot table
Pivotdata_fmt="#,###,$###"                 formats one or more values specified in the data area
Pivotdata_stats="max,min"                  provides summary functions for one or more values specifed in the data area
                                           default is sum statistic; 
                                                  other summary functions are 
                                                  average, count, countnums, max, min, product,stddev,stddev,sum,var, varp
Pivotcalc="row"                            performs calculation on the statistics such as percentage of row, column and total;
                                                  valid values are row, column, total, percentOf, index, and runningTotal
Pivot_format="light1"                      provides excel style for the pivot table;
Pivot_series="yes"                         specifies that one or more pivot tables are creted from the same worksheet 
pivotcharts="yes"                          indicates that you want to generate a pivotchart;
                                                   used in conjunction with the chart_type= option 
pivot_sheet_name="name(s)"                 provides the ability to specify worksheet names for the pivot tables; 
pivot_chart_name="name(s)"                 provides the ability to specify worksheet names for the pivot charts; 
pivot_zoom="number"                        modifies the current zoom for pivot table
pivot_title="text"                         specifies text to add for the pivot table 

output_type="script"                       creates a script files which can be executed by double clicking on the file or using the 
                                           'X' statement within the code to execute the file                                                  


ptsource_range="range"                     range of data to add to pivot table     
ptdest_range="range"                       range to write the pivot tables;
                                                     if omitted, pivot table writes to 
                                                     a new worksheet
format_conditon="databar,b1:d20"           specifies the type of visualization to add to columns of the pivot table such as databars, iconsets, colorscales, cellvalue or
                                           or expression;
                                           the type of condition is added followed by the range to add the bars to;
                                                 adding iconsets takes the formatting condition followed by the range to apply the icon to and the number representing
                                                      the icon which is 1-10.
                                                 adding the colorscale takes the formatting condition followed by the range to add the colorscale.
                                                 adding the cellvalue takes the formatting condition followed by the range to apply the condition to along with the 
                                                     operator and condtion. (ex. cellvalue,a3:b20,6,6000)
                                                 adding the expression takes the formatting conditon followed by the range, the operator, and the condition.     
                                                 
                                                *The operators that are available for the formula are 0 (none),1 (between), 2 (not between), 3 (equal), 4 (not equal), 5 ( greater) , 6 ( less) ,
                                                                                                      7 (greater equal), and 8 (less equal).
                                                 
databar_color="number"                     provides the colorindex for databars when added using the format_condition= option 
cellvalue_color="number"                   provides the colorindex for cellvalues when added using the format_condition= option 
expression_color="number"                  provides the colorindex for expressions when added using the format_condition= option 


addfield="xxx =0,yyy =1"                  Adds calculated field(s) to the pivot table using formulas;
                                                 also columns added also needs to be added to the pivotdata= option 
                                                 
pivot_layout="tabular"                    Allows the pivot table layout to be modified;
                                                     default layout is compact; other value values
                                                     are outline and tabular
						                                             
pivot_slicer="names(s)"                   column names for pivot slicer;     
                                                     to add more than one slicer, separate 
                                                     list items with commas
                                                     
pivot_slicer_position="200,10,100,100"    Provides the ability to add the x,y position and the 
                                          height and width for the pivot slicer
                                                     to add more than one slicer position, separate 
                                                     list items with a tilde                                           
                                          
pivotpage_filter="value(s)"               Allows pre-populated values of the columns specified with the PIVOTPAGE= option to be added 
                                                    to add more than one preselected filter, separate 
                                                    list items with commas
                                                     
pivot_sort="name(s),2"                    provides the ability to modify the sort order with the parameter 2 specifying a descending sort
                                                    to add more than one column and sort order, separate 
                                                    list items with tilde
         
dashboard="yes|no"                        Allows multiples tables and graphs added to a single worksheet when the PIVOT_SERIES= option is specified 

data2columns="yes|no"                      allows the summary field to be moved from the row to the column
          

chart_type="type"                          Excel's chart type to be used
chart_source="d:d"                         data range to use for the chart 
chart_title="string"                       string sprecified for chart title
chart_title_size="size"                    provides font size to the chart title
chart_title_color="color"                  provides color for the chart title
chart_xaxes_title="string"                 specifies a title for the X axes
chart_xaxes_size="size"                    specifies size for the X axes title
chart_xaxes_orientation="45"               modifies the orientation of the axis
chart_yaxes_title="string"                 specifies a title for the Y Axes
chart_yaxes_numberformat                   modifies the format of the axis
Chart_yaxes_title="string"                 specifies size for the Y axes title
chart_yaxes_orientation="45"               modifies the orientation of the axis
chart_yaxes_maxscale="4000"                modifies the axis scale
chart_yaxes_minscale="1000"                modifies the axis scale;
chart_area_color="color"                   specifies color for chart area
chart_plotarea_color="color"               specifies color for the plot area
chart_datalabels="yes|no|value"            adds data labels to the chart;
                                               valid values are value, percent, 
                                               labelandpercent, showbubblesizes

Chart_location="same_sheet|new_sheet|      specifies location to place charts;
                sheet_name"                    places charts on a new sheet by default

chart_location="0,100,300,400"             specifies top,left,height and width for embedded charts
chart_style="light1"                       specifies the style for charts;
                                               values are light1-light13,medium1-medium13,dar1-dark13
chart_legend="bottom"                      modifies the location of the legend
 
auto_excel="yes|no"                        starts export to Excel after the page has been loaded
embedded_title="yes|no"                    adds titles within worksheets for a single table
embedded_tables="yes|yes"                  adds multiple tables within a worksheet
number_format="@|#,##"                     applies excel formats to each column separated by a "|".
                                     

-----------------------------------------------------------------------------
Informative and window Options          
-----------------------------------------------------------------------------
include="file"                             allows other files to be included to 
                                                     the page such as HTML, RTF, PDF
window_title="string"                      name the window;
                                                     this title is also used when saved 
                                                     as favorite
load_msg="yes|no"                          generates a message while page is loading
load_image="image"                         generates message and image while page loading;
                                                     see zip file for animated image which can be used
alert_text="string"                        specifies string to display when the  page is loaded     
window_status="string"                     text to display in the task bar  
window_size="500,500|max"                  allows window size to be specified;
                                                     can specify coordinates or max to 
                                                     maximize window
fit2page_msg="yes|no"                      adds information on the percentage output is scaled
caption_text="caption1,caption2"           text added to the caption of the table                                                    
caption_just="left|right|center"           justifies the caption of the table
caption_backround="color"                  specifies background color for the caption
caption_color="color"                      specifies foreground color for the caption
caption_style="normal|italic|oblique"      modifies style of the caption
caption_image="path"                       provides image for the caption
doc="help"                                 display valid options and description

button_text="string"                       replace text for export button
button_fgcolor="color"                     foreground color of export button text
button_bgcolor="color"                     background color of export button text
button_size="12pt"                         size of export button text
                                                                     
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

powerpoint_master="primary#secondary"      specifies text to display on the master slide;
                                                     primary and sub title are separate by "#"
powerpoint_slides="a.html,b.html"          specifies HTML files to provide as individual slides
powerpoint_template="path"                 supplies a PowerPoint to use for the formatting
powerpoint_saveas="path"                   saves PowerPoint presentation to a slide
powerpoint_runs="yes|no"                   runs PowerPoint presentation
auto_powerpoint="yes|no"                   starts export to PowerPoint after the page has been loaded








